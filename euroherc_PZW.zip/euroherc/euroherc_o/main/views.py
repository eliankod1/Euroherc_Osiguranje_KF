from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from .models import *
from .forms import KlijentForm, CreateUserForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.views.generic import ListView
# Create your views here.

def registerPage(request):

    if request.user.is_authenticated:
        return redirect ('home')
    else:
        form = CreateUserForm()

        if request.method == "POST":
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                return redirect('home')

        context={'form':form}
        return render(request, 'main/register.html', context)

def loginPage(request):
    if request.user.is_authenticated:
        return redirect ('home')
    else:
        if request.method == "POST":
            username = request.POST.get('username')
            password = request.POST.get('password')

            user = authenticate(request, username=username, password=password)

            if user is not None:
                login(request, user)
                return redirect('home')
        context={}
        return render(request, 'main/login.html', context)

def logoutUser(request):
    logout(request)
    return redirect('login')

@login_required(login_url='login')
def home(request):
    police = Polica.objects.all()
    klijenti = Klijent.objects.all()
    podruznice = Podruznica.objects.all()

    putno = Klijent.objects.filter(polica__vrsta__icontains='Putno').count()
    obiteljsko = Klijent.objects.filter(polica__vrsta__icontains='Obiteljsko').count()
    imovinsko = Klijent.objects.filter(polica__vrsta__icontains='Imovinsko').count()
    kasko = Klijent.objects.filter(polica__vrsta__icontains='Kasko').count()
    zdravstveno = Klijent.objects.filter(polica__vrsta__icontains='Zdravstveno').count()


    context = {'police':police, 'klijenti':klijenti, 'podruznice':podruznice, 'putno':putno,
    'obiteljsko':obiteljsko, 'imovinsko':imovinsko, 'kasko':kasko, 'zdravstveno':zdravstveno}
    return render(request, "main/dashboard.html", context)

@login_required(login_url='login')
def podruznice(request):
    podruznice = Podruznica.objects.all()
    return render(request, "main/podruznice.html", {'podruznice':podruznice})


@login_required(login_url='login')
def police(request):
    police = Polica.objects.all()
    return render(request, "main/police.html", {'police':police})

@login_required(login_url='login')
def klijenti(request, pk_test):
    klijent = Klijent.objects.get(id=pk_test)

    context = {'klijent':klijent}
    return render(request, "main/klijenti.html", context)

@login_required(login_url='login')
def createKlijent(request):

    form = KlijentForm()
    if request.method == 'POST':
        print('Printing POST: ', request.POST)
        form = KlijentForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('/')


    context = {'form':form}
    return render(request, 'main/klijent_form.html', context)

@login_required(login_url='login')
def updateKlijent(request, pk):

    klijent = Klijent.objects.get(id=pk)

    form = KlijentForm(instance=klijent)

    if request.method == 'POST':
        form = KlijentForm(request.POST, instance=klijent)
        if form.is_valid():
            form.save()
            return redirect('/')

    context = {'form':form}
    return render(request, 'main/klijent_form.html', context)

@login_required(login_url='login')
def deleteKlijent(request, pk):
    klijent = Klijent.objects.get(id=pk)
    if request.method == "POST":
        klijent.delete()
        return redirect('/')
    
    context = {'item':klijent}
    return render(request, 'main/delete.html', context)