from django.contrib import admin
from .models import Podruznica, Polica, Klijent
# Register your models here.

admin.site.register(Podruznica)
admin.site.register(Polica)
admin.site.register(Klijent)