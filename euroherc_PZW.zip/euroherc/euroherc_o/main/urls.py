from django.urls import path
from . import views


urlpatterns = [
    path('register/', views.registerPage, name="register"),
    path('login/', views.loginPage, name="login"),
    path('logout/', views.logoutUser, name="logout"),
    path('', views.home, name="home"),
    path('podruznice/', views.podruznice, name="podruznice"),
    path('police/', views.police, name="police"),
    path('klijenti/<str:pk_test>/', views.klijenti, name="klijenti"),
    path('create_klijent/', views.createKlijent, name="create_klijent"),
    path('update_klijent/<str:pk>/', views.updateKlijent, name="update_klijent"),
    path('delete_klijent/<str:pk>/', views.deleteKlijent, name="delete_klijent"),
]