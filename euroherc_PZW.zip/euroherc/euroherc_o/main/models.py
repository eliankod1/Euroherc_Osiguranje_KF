from django.db import models

# Create your models here.


class Podruznica(models.Model):
    mjesto = models.CharField(max_length=50, null=True)

    def __str__(self):
        return self.mjesto


class Polica(models.Model):
    vrsta = models.CharField(max_length=50, null=True)
    trajanje = models.IntegerField(null=True)

    def __str__(self):
        return self.vrsta

class Klijent(models.Model):
    ime = models.CharField(max_length=50, null=True)
    prezime = models.CharField(max_length=50, null=True)
    polica = models.ForeignKey(Polica, null=True, on_delete=models.CASCADE)
    podruznica = models.ForeignKey(Podruznica, null=True, on_delete= models.CASCADE)
    def __str__(self):
        return self.prezime